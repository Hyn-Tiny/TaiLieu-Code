using System;
namespace FactoryMethod
{
    public class Duck : IAnimal
  {
    public void getName()
    {
      Console.WriteLine("quck quck");
    }
  }
}