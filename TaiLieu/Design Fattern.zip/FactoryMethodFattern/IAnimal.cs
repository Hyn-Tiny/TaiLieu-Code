using System;
namespace FactoryMethod
{
    public interface IAnimal
    {
        void getName();
    }
}