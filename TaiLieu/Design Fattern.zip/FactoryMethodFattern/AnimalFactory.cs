using System;

namespace FactoryMethod
{
    public abstract class AnimalFactory
  {
    public abstract IAnimal CreateAnimalFactory();
  }
}