namespace AdapterPattern
{
    public  interface ITarget
    {
        string GetRequest();
    }
}