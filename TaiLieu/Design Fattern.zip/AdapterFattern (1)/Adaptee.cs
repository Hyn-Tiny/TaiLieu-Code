namespace AdapterPattern
{
    public class Adaptee
    {
        public string GetSpecificRequest()
        {
            string c = "Specific Request";
            return c;
        }
    }
}