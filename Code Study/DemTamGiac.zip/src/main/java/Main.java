// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {
    Diem A = new Diem(1, 2);
    Diem B=new Diem(3,4);
    Diem C=new Diem(5,6);
    
    System.out.println(A);
    System.out.println("Khoang cach AB: "+A.tinhKhoangCach(B));
    System.out.println(B);
    System.out.println("Khoang cach AC: "+A.tinhKhoangCach(C));
    System.out.println(C);
    System.out.println("Khoang cach BC: "+B.tinhKhoangCach(C));

    TamGiac tg=new TamGiac(A,B,C);
    System.out.println(tg.tinhChuVi());
    System.out.println(tg.tinhDienTich());
  }

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}