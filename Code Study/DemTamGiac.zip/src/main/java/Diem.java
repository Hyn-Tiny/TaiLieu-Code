public class Diem{
  private float x;
  private float y;
  
  public Diem(){}
  public Diem(int x, int y){
    this.x=x;
    this.y=y;
  }
  public void setX(float x){
    this.x=x;
  }  
  public float getX(){
    return x;
  }
  public void setY(float y){
    this.y=y;
  }
  public float getY(){
    return y;
  }
  public String toString(){
    return "("+x+","+y+")";
  }
  public float tinhKhoangCach(Diem d2){
    return (float) Math.sqrt((x-d2.x)*(x-d2.x)+(y-d2.y)*(y-d2.y));
  }
  
}