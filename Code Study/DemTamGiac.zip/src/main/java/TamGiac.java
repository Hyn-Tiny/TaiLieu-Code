public class TamGiac{
  private Diem A;
  private Diem B;
  private Diem C;
  float AB, BC, AC;

  public TamGiac(){}
  public TamGiac(Diem A, Diem B, Diem C){
    this.A=A;
    this.B=B;
    this.C=C;
    AB=A.tinhKhoangCach(B);
    AC=A.tinhKhoangCach(C);
    BC=B.tinhKhoangCach(C);
  }
  public float tinhChuVi(){
    
    return (AB+AC+BC);
  }
  public float tinhDienTich(){
     float p=tinhChuVi()/2;
    return (float) Math.sqrt(p*(p-AB)*(p-AC)*(p-BC));
  }
}