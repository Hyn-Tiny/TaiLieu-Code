
public class CanBo{
  private String hoTen;
  private String ngaySinh;
  private String gioiTinh;
  private String diaChi;
  
  //contructor can bo 1 tham so
  public CanBo(){}
  //contructor can bo 4 tham so
  public CanBo(String hoTen,String ngaySinh,String gioiTinh,String diaChi){
    this.hoTen=hoTen;
    this.ngaySinh=ngaySinh;
    this.gioiTinh=gioiTinh;
    this.diaChi=diaChi;
  }
  
  //ham trar ve gia tri ho ten
  public void setHoTen(String hoTen){
    this.hoTen=hoTen;
  }
  
  public String getHoTen(){
    return hoTen;
  }
  public String toString() {
      return "Ho Ten: " + hoTen + ", Ngay Sinh: " + ngaySinh + ", Gioi Tinh: " + gioiTinh + ", Dia Chi: " + diaChi;
  }
}