import java.util.List;
import java.util.ArrayList;

public class QLCB{
  private List<CanBo>dscb;
  public QLCB(){
    dscb=new ArrayList<CanBo>();
  }
  public void themCanBo(CanBo cb){
      dscb.add(cb);
  }
  public void hienThi(){
    for(CanBo cb:dscb){
      System.out.println(cb);
    }
  }
}