public class NhanVien extends CanBo{
  private String congViec;

  public NhanVien(){}
  public NhanVien(String hoTen,String ngaySinh,String gioiTinh,String diaChi,String congViec){
super(hoTen,ngaySinh,gioiTinh,diaChi);
    this.congViec=congViec;
  }
  
  public void setHoTen(String congViec){
    this.congViec=congViec;
  }

  public String getHoTen(){
    return congViec;
  }
  public String toString() {
      return super.toString() + ", Cong Viec: " + congViec;
  }
}