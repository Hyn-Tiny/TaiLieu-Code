// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

public class Main {
  public static void main(String[] args) {

    CanBo cb = new CanBo("Nguyen Van A", "01/01/2001", "Nam", "Ha Noi");
    CanBo cb1 = new CanBo("Nguyen Van B", "03/09/2002", "nữ","Hà Nam");
    NhanVien nv = new NhanVien("Nguyen Van B", "01/01/2001", "Nam", "ha noi", "ky su");

    // System.out.println(cb);
    // System.out.println(nv);

    QLCB qlcb = new QLCB();
    qlcb.themCanBo(cb);
    qlcb.themCanBo(cb1);
   
      qlcb.hienThi();

    // void addition() {
    // assertEquals(2, 1 + 1);
    // }
  }
}
